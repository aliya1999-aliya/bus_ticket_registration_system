<?php
header("location: booking/");

?>